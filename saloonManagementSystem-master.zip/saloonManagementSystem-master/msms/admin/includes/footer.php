<!--footer-->
    <div class="footer">
       <p>&copy; 2022  Salon Management System Admin Panel.</p>
    </div>
        <!--//footer-->